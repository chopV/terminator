<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Терминатор</title>

	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/bootstrap-theme.min.css">
	<link rel="stylesheet" href="css/components-md.min.css">
	<link rel="stylesheet" href="css/profile.min.css">
	<link rel="stylesheet" href="css/plugins-md.min.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<script src="js/jquery-3.2.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.validate.min.js"></script>
	<script src="js/additional-methods.min.js"></script>

</head>

<body style="background-color: #ddd;">

	<div id="modal_alert" class="modal fade bs-modal-sm" tabindex="-1" role="dialog" aria-hidden="true" style="display: none;">
		<div class="modal-dialog modal-sm">
			<div class="modal-content">
				<div class="panel panel-default">
					<div class="panel-heading" id="modal_head"><i class="fa fa-info-circle"></i>&nbsp;Сообщение системы</div>
					<div class="panel-body" id="alert_body"></div>
				</div>
			</div>
		</div>
	</div>

	<nav class="navbar navbar-inverse navbar-fixed-top">
		<div class="container">
			<div class="navbar-header">
				<a class="navbar-brand" href="<?php print route('index'); ?>">
					<i class="fa fa-home"></i>&nbsp;Терминатор
				</a>
			</div>
			<div id="navbar" class="navbar-collapse collapse">
				<ul class="nav navbar-nav">
					<li id="menu_settings" class="active">
						<a href="<?php print route('settings'); ?>">
							<i class="fa fa-cog"></i>Настройки
						</a>
					</li>
					<li id="menu_farm">
						<a href="<?php print route('farm'); ?>">
							<i class="fa fa-optin-monster"></i>&nbsp;Ферма
						</a>
					</li>
				</ul>
			</div>
		</div>
	</nav>
	<div class="container" role="main" style="margin-top: 75px;">
		<?php echo $__env->yieldContent('content'); ?>
	</div>

</body>
</html>