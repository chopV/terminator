<?php $__env->startSection('content'); ?>
<style>
	/* Нехорошо вставлять css в страницу, но ради одного стиля, */
	/* который нигде больше не будет применяться,               */
	/* не будем морочить себе голову                            */
	.img_rihgt {
		position: absolute;
		top: 20px;
		right: 20px;
		line-height: 1px;
	}
</style>

<script type="text/javascript">
jQuery(document).ready(function(){

	jQuery('#menu_settings').removeClass('active');
	jQuery('#menu_farm').removeClass('active');

});
</script>

<div class="col-md-2"></div>
<div class="portlet light col-md-8">
	<div class="profile-userpic">
		<img class="img-responsive img_rihgt" alt="Овечка" src="img/sheep_04.gif" style="height: 150px; width: 150px;">
	</div>
	<div class="portlet-title">
		<div class="caption">
			<span class="caption-subject font-blue-madison bold uppercase">
				<i class="fa fa-info-circle"></i>&nbsp; Тестовое задание:
			</span>
		</div>
	</div>
	<div class="portlet-body">
		<ul>
			<li>Написать API с использованием RESTful</li>
			<li>Работу на FronEnd-e с написанным API</li>
			<li>Проектирование БД</li>
		</ul>
		<h4 class="font-blue-madison"><i class="fa fa-check-square-o"></i>&nbsp;Правила:</h4>
		<ul>
			<li>4 загона для овечек</li>
			<li>изначальное количество овечек 10 расположены рандомно по загонам</li>
			<li>1 день длится 10 секунд</li>
			<li>каждый день в одном из загонов где больше 1 овечки появляется ещё одна овечка</li>
			<li>каждый 10 день одну любую овечку забирают(сами знаете куда)</li>
			<li>если в загоне осталась одна овечка то берём загон где больше всего овечек и пересаживаем одну из них к одинокой овечке</li>
			<li>загоны никогда не должны быть пусты</li>
			<li>должен вестись счёт дней, который не обнуляется при обновлении страницы</li>
			<li>должна быть история действий происходящих в загонах(выводить никуда не надо)</li>
		</ul>
		<h4 class="font-blue-madison"><i class="fa fa-check-square-o"></i>&nbsp;Плюсом будет:</h4>
Страничка с отчётом за каждый день или период дней по запросу. Где мы должны видеть:
		<ul>
			<li>общее количество овечек</li>
			<li>количество убитых овечек</li>
			<li>количество живых овечек</li>
			<li>номер самого населённого загона</li>
			<li>номер самого менее населённого загона</li>
		</ul>
		<h4 class="font-blue-madison"><i class="fa fa-check-square-o"></i>&nbsp;Примечание:</h4>
Для решения данной задачи предлагается использовать следующие технологии\языки\фреймворки\библиотеки:
		<ul>
			<li><span class="bold">BackEnd:</span>
			<ul>
				<li>Laravel 5.4</li>
				<li>MySQL или PostgreSQL или SQLite</li>
			</ul>
			</li>
			<li><span class="bold">FrontEnd:</span>
			<ul>
				<li>Vue JS, Bootstrap или любой другой</li>
			</ul>
			</li>
		</ul>
Результат предоставить ссылкой на гитхаб
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>