@extends('layouts.app')

@section('content')

<script type="text/javascript">
jQuery(document).ready(function(){

	jQuery('#menu_settings').removeClass('active');
	jQuery('#menu_farm'    ).removeClass('active');
	jQuery('#menu_settings').addClass('active');

	$( "#form_settings" ).validate( {
		rules: {
			quantity_sheep:{
				required: true,
				digits: true,
			},
			quantity_corral:{
				required: true,
				digits: true,
			},
		},
		messages: {
			quantity_sheep: {
				required: "Введите количество",
			},
			quantity_corral: {
				required: "Введите количество",
			},
		},
		errorElement: "em",
		errorPlacement: function ( error, element ) {
			error.addClass( "help-block" );
			if ( element.prop( "type" ) === "checkbox" ) {
				error.insertAfter( element.parent( "label" ) );
			} else {
				error.insertAfter( element );
			}
		},
		highlight: function ( element, errorClass, validClass ) {
			$( element ).parents( ".col-sm-7" ).addClass( "has-error" ).removeClass( "has-success" );
		},
		unhighlight: function (element, errorClass, validClass) {
			$( element ).parents( ".col-sm-7" ).addClass( "has-success" ).removeClass( "has-error" );
		}
	});

	jQuery('#btn_save').click(function(){

		jQuery.ajax({
			url     : '<?php print route('save'); ?>',
			type    : 'POST',
			data    : {
				_token : "<?php print csrf_token(); ?>",
				quantity_sheep : jQuery('#quantity_sheep').val(),
				quantity_corral: jQuery('#quantity_corral').val(),
			},
			cache   : false,
			success : function(respond, textStatus, jqXHR){
				jQuery('#modal_alert').modal();
				jQuery('#alert_body').html(respond);
			},
			error   : function(xhr, ajaxOptions, thrownError){
				str_error = '<br>statusText = ' + xhr.statusText +
				'<br>responseText = ' + xhr.responseText +
				'<br>status = ' + xhr.status +
				'<br>thrownError = ' + thrownError;

				jQuery('#modal_alert').modal();
				jQuery('#alert_body' ).html('ОШИБКИ AJAX запроса: ' + str_error);
			}
		});
	});

});
</script>

<div class="col-md-3"></div>
<div class="portlet light col-md-6">
	<div class="portlet-title">
		<div class="caption">
			<span class="caption-subject font-blue-madison bold uppercase">
				<i class="fa fa-cog"></i>&nbsp;Настройки
			</span>
		</div>
	</div>
	<div class="portlet-body form">
		<form class="form-horizontal" role="form" id="form_settings">
			<div class="form-body">
				<div class="form-group">
					<label class="col-md-5 control-label" for="quantity_sheep">Количество овечек</label>
					<div class="col-sm-7">
						<input id="quantity_sheep"
							name="quantity_sheep"
							class="form-control"
							placeholder="Введите количество"
							type="text"
							value="<?php print $count_sheep; ?>">
					</div>
				</div>
				<div class="form-group">
					<label class="col-md-5 control-label">Количество загонов</label>
					<div class="col-sm-7">
						<input id="quantity_corral"
							name="quantity_corral"
							class="form-control"
							placeholder="Введите количество"
							type="text"
							value="<?php print $count_corral; ?>">
					</div>
				</div>
			</div>
			<div class="form-actions right">
				<span class="btn blue-madison btn-sm" id="btn_save">Сохранить настройки</span>
			</div>
		</form>
		<div class="alert alert-warning">
			<strong class="font-red"><i class="fa fa-exclamation-circle"></i>&nbsp;Внимание!</strong>
			<ul>
				<li>Количество овечек должно быть больше 0.</li>
				<li>Количество загонов должно быть больше 0.</li>
				<li>Количество овечек должно быть больше количества загонов минимум в два раза.</li>
			</ul>
			<strong class="font-red">При сохранении настроек все имеющиеся данные будут уничтожены!</strong>
		</div>
	</div>
</div>

@endsection