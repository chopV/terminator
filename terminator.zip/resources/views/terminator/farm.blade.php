@extends('layouts.app')
@section('content')
<script type="text/javascript">
jQuery(document).ready(function(){

	jQuery('#menu_settings').removeClass('active');
	jQuery('#menu_farm'    ).removeClass('active');
	jQuery('#menu_farm'    ).addClass('active');

	jQuery('#div_farm'  ).load('<?php print route('getfarm'  ); ?>');
	jQuery('#div_report').load('<?php print route('getreport'); ?>');

	var timerID;
	jQuery('#btn_start').click(function(){
		jQuery('#btn_start').removeClass('btn-default');
		jQuery('#btn_start').addClass('blue-madison');
		timer = 1000 * jQuery('#duration_day').val();
		timerID = setInterval(function(){
			jQuery.ajax({
				url     : '<?php print route('addday'); ?>',
				type    : 'POST',
				data    : {
					_token : "<?php print csrf_token(); ?>",
				},
				cache   : false,
				success : function(respond, textStatus, jqXHR){
					jQuery('#div_farm'  ).load('<?php print route('getfarm'  ); ?>');
					jQuery('#div_report').load('<?php print route('getreport'); ?>');

// 					jQuery('#modal_alert').modal();
// 					jQuery('#alert_body').html(respond);
// 					clearInterval(timerID);
				},
				error   : function(xhr, ajaxOptions, thrownError){
					clearInterval(timerID);
					str_error = '<br>statusText = ' + xhr.statusText +
					'<br>responseText = ' + xhr.responseText +
					'<br>status = ' + xhr.status +
					'<br>thrownError = ' + thrownError;

					jQuery('#modal_alert').modal();
					jQuery('#alert_body' ).html('ОШИБКИ AJAX запроса: ' + str_error);
				}
			});

		}, timer);
	});
	jQuery('#btn_stop').click(function(){
		clearInterval(timerID);
		jQuery('#btn_start').removeClass('blue-madison');
		jQuery('#btn_start').addClass('btn-default');
		jQuery('#modal_alert').modal();
		jQuery('#alert_body' ).html('Работу закончил');
	});

});
</script>

<div class="col-md-6">
	<div class="portlet light">
		<div class="portlet-title">
			<div class="caption">
				<span class="caption-subject font-blue-madison bold uppercase">
					<i class="fa fa-optin-monster"></i>&nbsp; ФЕРМА&nbsp;-&nbsp;<span id="span_curent_day"></span>
				</span>
			</div>
			<div class="actions ">
				Длительность дня, с:&nbsp;
				<select id="duration_day">
					<option value="1">1</option>
					<option value="2">2</option>
					<option value="3">3</option>
					<option value="4">4</option>
					<option value="5">5</option>
					<option value="6">6</option>
					<option value="7">7</option>
					<option value="8">8</option>
					<option value="9">9</option>
					<option value="10">10</option>
				</select>&nbsp;&nbsp;
				<a id="btn_start" class="btn btn-circle btn-icon-only btn-default" title="Старт">
					<i class="fa fa-play-circle"></i>
				</a>
				<a id="btn_stop" class="btn btn-circle btn-icon-only btn-default" title="Стоп">
					<i class="fa fa-stop"></i>
				</a>
			</div>
		</div>
		<div class="portlet-body" id="div_farm">
		</div>
	</div>
</div>
<div class="col-md-6" id="div_report"></div>

@endsection
