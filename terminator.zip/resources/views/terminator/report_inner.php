<div class="portlet light">
	<div class="portlet-title">
		<div class="caption">
			<span class="caption-subject font-blue-madison bold uppercase">
				<i class="fa fa-bar-chart"></i>&nbsp; ОТЧЕТ
			</span>
		</div>
	</div>
	<div class="portlet-body">
		<table class="table table-bordered table-hover" id="table_report">
			<thead>
			<tr>
				<th class="text-center">День</th>
				<th class="text-center">Общее к-во</th>
				<th class="text-center">К-во убитых</th>
				<th class="text-center">К-о живых</th>
				<th class="text-center" colspan="2">MAX</th>
				<th class="text-center" colspan="2">MIN</th>
			</tr>
			</thead>
			<tbody>
			<?php
			foreach ($report as $row){
				?>
				<tr>
					<td class="text-center"><?php print str_replace(" ","&nbsp;",$row['day_caption']); ?></td>
					<td class="text-center"><?php print $row['number_total' ]; ?></td>
					<td class="text-center"><?php print $row['number_killed']; ?></td>
					<td class="text-center"><?php print $row['number_live'  ]; ?></td>
					<td class="text-center"><?php print str_replace(" ","&nbsp;",$row['most_caption' ]); ?></td>
					<td class="text-center"><?php print "(".$row['number_most'].")"; ?></td>
					<td class="text-center"><?php print str_replace(" ","&nbsp;",$row['least_caption']); ?></td>
					<td class="text-center"><?php print "(".$row['number_least'].")"; ?></td>
				</tr>
				<?php
			};
			?>
			</tbody>
		</table>
	</div>
</div>