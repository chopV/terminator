<script type="text/javascript">
jQuery(document).ready(function(){

	jQuery('#span_curent_day').html('<?php print $curent_day; ?>');


});
</script>
<?php
if(isset($farm) and (count($farm)>0)){
	foreach ($farm as $row){
		?>
	<div class="col-md-6">
		<div class="portlet box blue-madison">
			<div class="portlet-title">
				<div class="caption">
					<i class="fa fa-bars"></i>&nbsp;<?php print $row['caption']; ?>
				</div>
				<div class="actions">
					<span class="badge badge-warning"><?php print count($row['sheep']); ?></span>
				</div>
			</div>
			<div class="portlet-body">
				<div class="scroller" style="height:100px; overflow-y:scroll;">
			<?php
			foreach ($row['sheep'] as $row_sheep){
				?>
					<span class="col-md-12">
						<img alt="" src="img/sheep_icon.png" style="width: 13p; height: 13px;">
						<?php print $row_sheep['caption']; ?>
					</span>
				<?php
			};
			?>
				</div>
			</div>
		</div>
	</div>
		<?php
	};
};
?>
<div class="clearfix"></div>
