<?php

namespace App;

use Illuminate\Support\Facades\DB;

class Terminator{

	public $sheep;
	public $corral;
	public $herd;

	public function __construct(){
		$this->corral = new tableCorral;
		$this->sheep  = new tableSheep;
		$this->herd   = new tableHerd;
	}

	public function getFarm(){

		$array_corral = $this->corral->getItem();
		$i = 0;
		foreach ($array_corral as $row){
			$farm[$i]['id'     ]   = $row['id'     ];
			$farm[$i]['caption']   = $row['caption'];
			$this->herd->id_corral = $row['id'     ];
			$farm[$i]['sheep'  ]   = $this->herd->getHerd();
			$i = $i + 1;
		};
		return $farm;
	}

	public function getMostLeastHerd(){

		$array_corral = $this->corral->getItem();
		$array_herd = [];
		$i = 0;
		foreach ($this->corral->getItem() as $corral){
			$this->herd->id_corral = $corral['id'];
			$array_count[$corral['id']] = $this->herd->getCount();
			$i = $i + 1;
		};

		$result['all_herd'     ] = $array_count;
		$result['id_most_herd' ] = array_keys($array_count, max($array_count))[0];
		$result['number_most'  ] = max($array_count);
		$result['id_least_herd'] = array_keys($array_count, min($array_count))[0];
		$result['number_least' ] = min($array_count);

		return $result;

	}
}