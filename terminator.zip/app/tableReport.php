<?php
/**
 * Модель для работы с таблицей [Ежедневный отчет]
 */
namespace App;

use Illuminate\Support\Facades\DB;

class tableReport extends tableModel{

	public $id_day;			// Код дня
	public $number_total;	// Общее количество овечек
	public $number_killed;	// Количество убитых овечек
	public $number_live;		// Количество живых овечек
	public $id_most_herd;	// Код самого населённого загона
	public $number_most;		// Количество самого населённого загона
	public $id_least_herd;	// Код самого менее населённого загона
	public $number_least;	// Количество самого менее населённого загона

	public function __construct(){
		$this->table = "report";
	}

	/**
	 * Добавление записи
	 */
	public function insertItem(){
		$str_query = "
			INSERT INTO report (
				id_day,
				number_total,
				number_killed,
				number_live,
				id_most_herd,
				number_most,
				id_least_herd,
				number_least
			) VALUES (
				".$this->id_day.",
				".$this->number_total.",
				".$this->number_killed.",
				".$this->number_live.",
				".$this->id_most_herd.",
				".$this->number_most.",
				".$this->id_least_herd.",
				".$this->number_least."
			)
			";
// 		print "<pre>";print_r($str_query);print "</pre>";
		DB::statement('SET foreign_key_checks = 0');
		DB::insert($str_query);
	}

	public function getItem(){
		$str_query = "
			SELECT
				report.id_day,
				day.caption AS day_caption,
				report.number_total,
				report.number_killed,
				report.number_live,
				report.id_most_herd,
				most.caption AS most_caption,
				report.number_most,
				report.id_least_herd,
				least.caption AS least_caption,
				report.number_least
			FROM report
			LEFT JOIN day             ON day  .id = report.id_day
			LEFT JOIN corral AS most  ON most .id = report.id_most_herd
			LEFT JOIN corral AS least ON least.id = report.id_least_herd
		";
		foreach (DB::select($str_query) as $row){
			$result[] = (array)$row;
		};
		if(isset($result)){
			return $result;
		}else{
			return "Not found";
		};
	}

}