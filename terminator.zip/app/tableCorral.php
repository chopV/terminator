<?php
/**
 * Модель для работы с таблицей [Загоны]
 */
namespace App;

use Illuminate\Support\Facades\DB;

class tableCorral extends tableModel{

	public function __construct(){
		$this->table = "corral";
	}

}