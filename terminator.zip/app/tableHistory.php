<?php
/**
 * Модель для работы с таблицей [Дни]
 */
namespace App;

use Illuminate\Support\Facades\DB;

class tableHistory extends tableModel{

	public $herd;

	public function __construct(){
		$this->table = "history";
		$this->herd  = new tableHerd;
	}

	public function saveHistory($id_day){
		$array_herd = $this->herd->getItem();
		foreach ($array_herd as $row){
			$this->insertHistory($id_day,$row['id_corral'],$row['id_sheep']);
		};
	}

	public function insertHistory($id_day,$id_corral,$id_sheep){
		$str_query = "
			INSERT INTO history (
				id_day,
				id_corral,
				id_sheep
			) VALUES (
				".$id_day.",
				".$id_corral.",
				".$id_sheep."
			)
		";
		DB::insert($str_query);
	}

}