<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Terminator;
use App\tableSheep;
use App\tableCorral;
use App\tableHerd;
use App\tableDay;
use App\tableReport;
use App\tableHistory;

class TerminatorController extends Controller{

	public $sheep;
	public $corral;
	public $herd;
	public $day;
	public $report;
	public $history;

	/**
	 * @todo Для увеличения быстродейтсвия
	 * можно создавать объекты только в тех функциях,
	 * где они используются, но здесь это не критично,
	 * но более удобочитабельно
	 */
	public function __construct(){
		$this->farm    = new Terminator;
		$this->corral  = new tableCorral;
		$this->sheep   = new tableSheep;
		$this->herd    = new tableHerd;
		$this->day     = new tableDay;
		$this->report  = new tableReport;
		$this->history = new tableHistory;
	}

	/**
	 * Главная страница
	 */
	public function index(){
		$data = [];
		return view('terminator.index',$data);
	}

	/**
	 * Страница [Настройки]
	 */
	public function settings(){

		$data = [];

		// Количество овечек
		$data['count_sheep']  = $this->sheep->getCount();
		if($data['count_sheep'] == 0){
			$data['count_sheep'] = "";
		};

		// Количество загонов
		$data['count_corral']  = $this->corral->getCount();
		if($data['count_corral'] == 0){
			$data['count_corral'] = "";
		};

		return view('terminator.settings',$data);
	}

	/**
	 * Страница [Ферма]
	 */
	public function farm(){
		return view('terminator.farm');
	}

	/**
	 * Загрузка загонов фермы
	 */
	public function get_farm(){
		$data = [];
		$this->day->id = $this->day->getMaxID();
		$data['curent_day'] = $this->day->getItem()[0]['caption'];
		$data['farm'] = $this->farm->getFarm();
		return view('terminator.farm_inner',$data);
	}

	/**
	 * Загрузка отчета
	 */
	public function get_report(){
		$data = [];
		$data['report'] = $this->report->getItem();
		return view('terminator.report_inner',$data);
	}

	/**
	 * Создаем новый день
	 */
	public function add_day(){

		$number_killed = $this->report->getMAXColumn('number_killed');

		// 1. Создаем новый день
		$current_day = (int)$this->day->getMaxID() + 1;
		print "День ".$current_day;
		$this->day->caption = "День ".$current_day;
		$this->day->insertItem();

		// 2. Получаем список загонов, где овечек больше чем 1
		$array_herd     = $this->farm->getMostLeastHerd();
		$array_all_herd = $array_herd['all_herd'];
		foreach ($array_all_herd as $key => $value){
			if($value = 1){
				unset($array_all_herd[array_search($value, $array_all_herd)]);
			};
		};

		// 3. В один из этих загонов рендомно добавляем 1 овечку
		// добавляем овечку...
		$number_sheep = $this->sheep->getMaxID() + 1;
		$this->sheep->caption = "Овечка ".$number_sheep;
		$this->sheep->insertItem();

		// рендом массива загонов
		$id_corral = array_rand($array_all_herd,1);

		// помещаем овечку в загон
		$this->herd->id_corral = $id_corral;
		$this->herd->id_sheep = $number_sheep;
		$this->herd->insertItem();

		$array_herd = $this->farm->getMostLeastHerd();
		while ($array_herd['number_least']==1) {

			// 4. Находим загон, где 1 овечка
			if($array_herd['number_least']==1){
				$id_corral_min = $array_herd['id_least_herd'];
			};

			// 5. Находим загон с максимальным количеством овечек
			$id_corral_max = $array_herd['id_most_herd'];
			$this->herd->id_corral = $id_corral_max;

			// 6. Из МАКС пересаживаем 1 овечку в МИН
			$array_sheep = $this->herd->getHerd();
			$this->herd->id_sheep = $array_sheep[0]['id_sheep'];
			$this->herd->moveMaxMin($id_corral_max,$id_corral_min);

			$array_herd = $this->farm->getMostLeastHerd();
		};

		// 7. Если день 10-й - убиваем рендомно одну овечку
		if(($current_day%10)==0){
			$array_sheep = $this->sheep->getItem();
			$this->sheep->id = array_rand($array_sheep, 1);
			$this->sheep->deleteItem();
			$number_killed = $number_killed + 1;
		};

		// 8. Записываем отчет за день
		$array_report_herd = $this->farm->getMostLeastHerd();
		$quantity_sheep = $this->sheep->getCount();
		$id_current_day = (int)$this->day->getMaxID();

		$this->report->id_day        = $id_current_day;
		$this->report->number_total  = $quantity_sheep + $number_killed;
		$this->report->number_killed = $number_killed;
		$this->report->number_live   = $quantity_sheep;
		$this->report->id_most_herd  = $array_report_herd['id_most_herd' ];
		$this->report->number_most   = $array_report_herd['number_most'  ];
		$this->report->id_least_herd = $array_report_herd['id_least_herd'];
		$this->report->number_least  = $array_report_herd['number_least' ];
		$this->report->insertItem();

		// Записываем историю
		$this->history->saveHistory($id_current_day);

	}

	/**
	 * Сохранение настроек
	 *
	 * @todo Проверку соответствия условиям стоит вынести в Middleware.
	 * @todo Блоки создания/записи овечек/загонов/стад стоит вынести в соответствующие модели.
	 *
	 */
	public function save_settings(Request $request){

		$quantity_sheep  = (int)$request->input('quantity_sheep' );
		$quantity_corral = (int)$request->input('quantity_corral');

		// Проверка условий
		if($quantity_sheep<1){
			print "Количество овечек должно быть больше 0.";
			exit;
		};
		if($quantity_corral<1){
			print "Количество загонов должно быть больше 0.";
			exit;
		};
		if($quantity_sheep<($quantity_corral * 2)){
			print "Количество овечек должно быть больше количества загонов минимум в два раза.";
			exit;
		};

		// Создаем/Записываем овечек
		$this->sheep->clearAll();
		for($i=1;$i<=$quantity_sheep;$i++){
			$this->sheep->caption = "Овечка ".$i;
			$this->sheep->insertItem();
		};

		// Создаем/Записываем загоны
		$this->corral->clearAll();
		for($i=1;$i<=$quantity_corral;$i++){
			$this->corral->caption = "Загон ".$i;
			$this->corral->insertItem();
		};

		// Создаем/Записываем стада, в каждый загон помещаем по овечке

		// 1. По одной в каждый загон.
		$this->herd->clearAll();
		// Нарушение требования "изначальное количество овечек 10 расположены рандомно по загонам"
		// для того, чтобы выполнить требование "загоны никогда не должны быть пусты"
		for($i=1;$i<=$quantity_corral;$i++){
			$this->herd->id_corral = $i;
			$this->herd->id_sheep = $i;
			$this->herd->insertItem();
		};
		// 2. Остальных по рендом-генератору.
		for($i=($quantity_corral+1);$i<=$quantity_sheep;$i++){
			$this->herd->id_corral = rand(1,$quantity_corral);
			$this->herd->id_sheep = $i;
			$this->herd->insertItem();
		};

		// Создаем/записываем первый день
		$this->day->clearAll();
		$this->day->caption = "День 1";
		$this->day->insertItem();

		// Записываем отчет за первый день
		$this->report->clearAll();
		$array_herd = $this->farm->getMostLeastHerd();
		$this->report->id_day        = 1;
		$this->report->number_total  = $quantity_sheep;
		$this->report->number_killed = 0;
		$this->report->number_live   = $quantity_sheep;
		$this->report->id_most_herd  = $array_herd['id_most_herd' ];
		$this->report->number_most   = $array_herd['number_most'  ];
		$this->report->id_least_herd = $array_herd['id_least_herd'];
		$this->report->number_least  = $array_herd['number_least' ];
		$this->report->insertItem();

		// Записываем историю
		$this->history->clearAll();
		$this->history->saveHistory(1);

		print "Настройки сохранены.";
	}

}