<?php
/**
 * Модель для работы с таблицей [Овечки]
 */
namespace App;

use Illuminate\Support\Facades\DB;

class tableSheep extends tableModel{

	public function __construct(){
		$this->table = "sheep";
	}

}