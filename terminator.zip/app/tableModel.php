<?php
/**
 * Модель общих функций для работы с таблицами БД
 */
namespace App;

use Illuminate\Support\Facades\DB;

class tableModel{

	public $table;
	public $id;
	public $caption;

	/**
	 * Получений списка записей
	 * @return array|string
	 */
	public function getItem(){

		$str_where = "";
		if(isset($this->id)){
			$str_where = "AND id = ".$this->id;
		};

		$str_query = "
			SELECT *
			FROM ".$this->table."
			WHERE 1 = 1
				".$str_where."
		";

		foreach (DB::select($str_query) as $row){
			$result[] = (array)$row;
		};
		if(isset($result)){
			return $result;
		}else{
			return "Not found";
		};
	}

	/**
	 * Добавление записи
	 */
	public function insertItem(){
		DB::insert("INSERT INTO ".$this->table." (caption) VALUES (?)",[$this->caption]);
	}

	/**
	 * Очистка таблицы
	 */
	public function clearAll(){
		DB::delete("DELETE FROM ".$this->table);
		DB::statement("ALTER TABLE ".$this->table." AUTO_INCREMENT=1");
	}

	/**
	 * Получение количества записей таблицы
	 * @return array
	 */
	public function getCount(){
		$array_count = (array)DB::select("SELECT count(*) AS count_row FROM ".$this->table)[0];
		$result = $array_count['count_row'];
		return $result;
	}

	public function getMaxID(){
		$str_query = "
			SELECT MAX(id) AS max_id
			FROM ".$this->table."
		";
		$array_result = (array)DB::select($str_query)[0];
		$result = $array_result['max_id'];
		return $result;
	}

	public function getMAXColumn($column){
		$str_query = "
			SELECT MAX(".$column.") AS max_column
			FROM ".$this->table."
		";
		$array_result = (array)DB::select($str_query)[0];
		$result = $array_result['max_column'];
		return $result;
	}




	public function deleteItem(){

		$str_query = "
			DELETE FROM ".$this->table."
			WHERE id = ".$this->id."
		";
		DB::delete($str_query);
	}

}