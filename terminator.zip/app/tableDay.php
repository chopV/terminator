<?php
/**
 * Модель для работы с таблицей [Дни]
 */
namespace App;

use Illuminate\Support\Facades\DB;

class tableDay extends tableModel{

	public function __construct(){
		$this->table = "day";
	}
}