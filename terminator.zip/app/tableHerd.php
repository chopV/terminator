<?php
/**
 * Модель для работы с таблицей [Овцы в загонах]
 */
namespace App;

use Illuminate\Support\Facades\DB;

class tableHerd extends tableModel{

	public $id_corral;
	public $id_sheep;

	public function __construct(){
		$this->table = "herd";
	}

	public function insertItem(){
		DB::insert("INSERT INTO ".$this->table." (id_corral,id_sheep) VALUES (?,?)",[$this->id_corral,$this->id_sheep]);
	}

	public function getHerd(){

		$str_query = "
			SELECT
				herd .id_sheep,
				sheep.caption
			FROM herd
			LEFT JOIN sheep ON sheep.id = herd.id_sheep
			WHERE herd.id_corral = :id_corral
			";
		foreach (DB::select($str_query,['id_corral' => $this->id_corral]) as $row){
			$result[] = (array)$row;
		};
		return $result;
	}

	public function moveMaxMin($id_corral_from,$id_corral_to){

		$str_query = "
			UPDATE herd
			SET id_corral = ".$id_corral_to."
			WHERE id_corral = ".$id_corral_from." AND id_sheep = ".$this->id_sheep."
		";
		DB::update($str_query);
	}

	public function getCount(){

		if(isset($this->id_corral)){
			$str_query = "
				SELECT count(*) AS count_row
				FROM ".$this->table."
				WHERE id_corral = ?
			";
			$data = [
				'id_corral' => $this->id_corral
			];
			$array_count = (array)DB::select($str_query,[$this->id_corral])[0];
		}else{
			$array_count = (array)DB::select("SELECT count(*) AS count_row FROM ".$this->table)[0];
		};
		$result = $array_count['count_row'];
		return $result;

	}


}