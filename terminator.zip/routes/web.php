<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get ('/'         , 'TerminatorController@index'        )->name('index'    );
Route::get ('/settings' , 'TerminatorController@settings'     )->name('settings' );
Route::get ('/farm'     , 'TerminatorController@farm'         )->name('farm'     );
Route::post('/save'     , 'TerminatorController@save_settings')->name('save'     );
Route::any ('/getfarm'  , 'TerminatorController@get_farm'     )->name('getfarm'  );
Route::any ('/getreport', 'TerminatorController@get_report'   )->name('getreport');
Route::any ('/addday'   , 'TerminatorController@add_day'      )->name('addday'   );